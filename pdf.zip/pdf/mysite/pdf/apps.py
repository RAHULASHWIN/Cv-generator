from django.apps import AppConfig


class PdfConfig(AppConfig):
    name = 'pdf'
